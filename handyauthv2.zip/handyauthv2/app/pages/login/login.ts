import { Component } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { NavController } from 'ionic-angular';
import { SignupPage } from '../signup/signup';
import { HomePage } from '../home/home';
import { Todos } from '../../providers/todos/todos';



@Component({
  templateUrl: 'build/pages/login/login.html',
  providers:[Todos]
})
export class LoginPage {
  identifier:  string;
  password:   string;

  constructor(private nav: NavController, private http: Http, private todoService: Todos) {
    
}
  login() {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    
    let credentials = {
     identifier: this.identifier,
      password:   this.password,
    };
     
   this.http.post('http://68.195.201.38:1337/auth/local',JSON.stringify(credentials), {headers: headers})
  
  .map(res => res.json())
  .subscribe (data => {
    console.log(data);/*Grab the authentication details here*/
     
   this.todoService.load(data.id)
    this.nav.setRoot(HomePage);
  }, (err) => {
    console.log(err);
  });

  }
  launchSignup() {
    this.nav.push(SignupPage);
  }
}
