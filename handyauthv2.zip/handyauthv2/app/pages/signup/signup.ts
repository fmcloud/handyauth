import { Component } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { NavController } from 'ionic-angular';
import { HomePage } from '../home/home';
import { Todos } from '../../providers/todos/todos';


@Component({
  templateUrl: 'build/pages/signup/signup.html',
  providers:[Todos]
})
export class SignupPage {
  
  nameFirst:    string;
  nameLast:     string;
  username:     string;
  password:     string;
  email:        string;

  constructor(private nav: NavController, private http: Http, private todoService: Todos) {

  }
  
  register() {
    let headers = new Headers () ;
    headers.append ('Content-Type', 'application/json');
    
    let user = {
      nameFirst:    this.nameFirst,
      nameLast:     this.nameLast,
      username:     this.username,
      password:     this.password,
      email:        this.email,
    };
    
     this.http.post('http://68.195.201.38:1337/auth/local/register',JSON.stringify(user), {headers: headers})

    .map(res => res.json())
  
  
  
  
  .subscribe (todos => {
    this.todoService = todos;
    this.nav.push(HomePage);
  }, (err) => {
    console.log(err);
  });
  }
  }
