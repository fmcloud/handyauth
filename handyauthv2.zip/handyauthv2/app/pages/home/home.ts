import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Http, Headers } from '@angular/http';
import { Todos } from '../../providers/todos/todos';

@Component({
  templateUrl: 'build/pages/home/home.html'
})
export class HomePage {
  

  constructor(public navCtrl: NavController, private todoService: Todos) {
 


  }
}
