import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';

/*
  Generated class for the Data provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class Todos {
  
  data:       any;
  passports:  any;
  profiles:   any;
  todos:      any;
  projects:   any;

  constructor(private http: Http) {
    
  }
  
  load(credentials){

		if(this.data){
			return Promise.resolve(this.data);
		}

		return new Promise(resolve => {

			this.http.get('http://68.195.201.38:1337/user/' + credentials).subscribe(res => {
		        this.data = res.json();
		        this.passports = this.data.passports;
		        this.profiles = this.data.profiles;
		        this.todos = this.data.todos;
		        this.projects = this.data.projects;

		        console.log(this.passports);
		        console.log(this.profiles);
		        console.log(this.todos);
		        console.log(this.projects);

		        resolve(this.data);
      		});

		});
	}

}



